<?php

namespace Database\Seeders;

use App\Models\Task;
use App\Models\User;
use Illuminate\Database\Seeder;

class TaskSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = User::where('email', 'test@example.com')->first();

        if (! $user) {
            return;
        }

        Task::factory()->count(5)->pending()->create(['user_id' => $user->id]);
        Task::factory()->count(3)->completed()->create(['user_id' => $user->id]);
    }
}
