@if (session('success'))
    <div class="mb-6 flex items-center gap-3 rounded-2xl border border-teal-200 bg-teal-50 px-4 py-3 text-teal-800 shadow-sm" role="alert">
        <svg class="h-5 w-5 shrink-0 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <span class="text-sm font-medium">{{ session('success') }}</span>
    </div>
@endif
