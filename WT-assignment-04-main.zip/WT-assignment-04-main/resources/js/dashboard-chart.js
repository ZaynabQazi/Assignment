import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('taskChart');

    if (!canvas || !window.taskChartData) {
        return;
    }

    const { completed, pending } = window.taskChartData;

    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: ['Completed', 'Pending'],
            datasets: [{
                label: 'Tasks',
                data: [completed, pending],
                backgroundColor: ['#14b8a6', '#ec4899'],
                borderRadius: 12,
                borderSkipped: false,
                maxBarThickness: 80,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false,
                },
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: '#64748b',
                    },
                    grid: {
                        color: '#e2e8f0',
                    },
                },
                x: {
                    ticks: {
                        color: '#334155',
                        font: { weight: '600' },
                    },
                    grid: {
                        display: false,
                    },
                },
            },
        },
    });
});
