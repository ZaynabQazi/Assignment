<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    /**
     * Display the user dashboard with task statistics and chart data.
     */
    public function index(Request $request): View
    {
        $user = $request->user();

        $totalTasks = $user->tasks()->count();
        $completedTasks = $user->tasks()->where('status', Task::STATUS_COMPLETED)->count();
        $pendingTasks = $user->tasks()->where('status', Task::STATUS_PENDING)->count();

        $recentTasks = $user->tasks()
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', [
            'totalTasks' => $totalTasks,
            'completedTasks' => $completedTasks,
            'pendingTasks' => $pendingTasks,
            'recentTasks' => $recentTasks,
            'chartData' => [
                'completed' => $completedTasks,
                'pending' => $pendingTasks,
            ],
        ]);
    }
}
